<?php /* Smarty version Smarty-3.1.21, created on 2015-04-11 10:19:03
         compiled from "view/templates/partial_modal_change_password.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7309245255270e1cbb2495-09097939%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '64e89aa2ac78730956dbdad73e0a2430c9d67854' => 
    array (
      0 => 'view/templates/partial_modal_change_password.tpl',
      1 => 1428740342,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7309245255270e1cbb2495-09097939',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_55270e1cbc0d12_46468181',
  'variables' => 
  array (
    'csrf_token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55270e1cbc0d12_46468181')) {function content_55270e1cbc0d12_46468181($_smarty_tpl) {?><div class="modal fade bs-modal-sm" id="change-psw-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="bs-example bs-example-tabs">
                <ul id="myTab" class="nav nav-tabs">
                  <li class="active"><a href="#change-psw" data-toggle="tab">Change password</a></li>
                </ul>
            </div>
            <div class="modal-body">
                <div id="myTabContent" class="tab-content">
                    <div class="tab-pane fade active in text-center" id="change-psw">
                        <form name="form-change-psw" id="form-change-psw" method="post" action ="/user/change-password">
                            <div class="form-group">
                                <div class="form-group has-feedback has-feedback-left">
                                    <label class="control-label" for="change-psw-current-psw">Current password</label>
                                    <input type="password" name="change_psw_current_psw" id="change-psw-current-psw" class="form-control" placeholder="Current password" />
                                    <span class="form-control-feedback glyphicon glyphicon-lock"></span>
                                </div>
                                <div class="form-group has-feedback has-feedback-left">
                                    <label class="control-label" for="change-psw-psw">New password</label>
                                    <input type="password" name="change_psw_psw" id="change-psw-psw" class="form-control" placeholder="New password" />
                                    <span class="form-control-feedback glyphicon glyphicon-lock"></span>
                                </div>
                                <div class="form-group has-feedback has-feedback-left">
                                    <label class="control-label" for="change-psw-psw2">Re-enter new password</label>
                                    <input type="password" name="change_psw_psw2" id="change-psw-psw2" class="form-control" placeholder="New password again" />
                                    <span class="form-control-feedback glyphicon glyphicon-lock"></span>
                                </div>
                                <div class="name-group">
                                    <input type="text" name="change_psw_csrf_token" id="change-psw-csrf-token" value="<?php if (isset($_smarty_tpl->tpl_vars['csrf_token']->value)) {
echo $_smarty_tpl->tpl_vars['csrf_token']->value;
}?>" />
                                    <input type="text" name="change_psw_name" id="change-psw-name" class="form-control" placeholder="E-mail" />
                                </div>
                                <div class="form-group text-center">
                                    <button type="button" name="change-psw-btn" id="change-psw-btn" class="btn btn-success">Change and Logout</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <button type="button" class="btn btn-default btn-block" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /#service-modal --><?php }} ?>
