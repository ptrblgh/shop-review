<?php /* Smarty version Smarty-3.1.21, created on 2015-04-13 11:53:55
         compiled from "view/templates/partial_form_review.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16646796525525b5ba4f8354-72710698%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f37e3a90ab26e96ad6319f25d227896533c98634' => 
    array (
      0 => 'view/templates/partial_form_review.tpl',
      1 => 1428918834,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16646796525525b5ba4f8354-72710698',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5525b5ba56bc75_43923332',
  'variables' => 
  array (
    'logged_in_review' => 0,
    'csrf_token' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5525b5ba56bc75_43923332')) {function content_5525b5ba56bc75_43923332($_smarty_tpl) {?><div class="section-your-review">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h3 class="page-header text-center text-uppercase">
                    <a name="my-review" href="#my-review" class="smooth-scroll">
                        <small><span class="glyphicon glyphicon-comment"></span></small> My review 
                    </a>
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <form name="form-review" id="form-review" method="post" action ="/review/add">
                    <div class="form-group">
                        <div class="form-group has-feedback has-feedback-left">
                            <label class="control-label">My review</label>
                            <textarea name="review_review_body" rows="5" class="form-control"><?php if (!empty($_smarty_tpl->tpl_vars['logged_in_review']->value->review_body)) {
echo $_smarty_tpl->tpl_vars['logged_in_review']->value->review_body;
}?></textarea>
                            <span class="form-control-feedback glyphicon glyphicon-pencil"></span>
                        </div>
                        <div class="form-group">
                            <label class="control-label">My rating</label>
                            <input class="rating" name="review_review_rating" value="<?php if (!empty($_smarty_tpl->tpl_vars['logged_in_review']->value->review_rating)) {
echo $_smarty_tpl->tpl_vars['logged_in_review']->value->review_rating;
}?>" data-min="0" data-max="5" data-step="1" data-size="sm">
                        </div>
                        <div class="name-group">
                            <input type="text" name="review_csrf_token" id="review-csrf-token" value="<?php if (isset($_smarty_tpl->tpl_vars['csrf_token']->value)) {
echo $_smarty_tpl->tpl_vars['csrf_token']->value;
}?>" />
                            <input type="text" name="review_name" id="review-name" class="form-control" placeholder="E-mail" />
                        </div>
                        <hr />
                        <?php echo $_smarty_tpl->getSubTemplate ("partial_errors.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                        <div class="form-group text-center">
                            <button name="review-btn" id="review-btn" type="button" class="btn btn-primary"><?php if (!empty($_smarty_tpl->tpl_vars['logged_in_review']->value)) {?>Update<?php } else { ?>Send<?php }?> review</button>
                            <a href="/review/del" name="delete-review-btn" id="delete-review-btn" type="button" class="btn btn-danger btn-confirm">Delete review</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php }} ?>
