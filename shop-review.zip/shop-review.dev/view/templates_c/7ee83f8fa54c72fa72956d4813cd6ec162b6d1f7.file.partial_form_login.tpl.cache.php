<?php /* Smarty version Smarty-3.1.21, created on 2015-04-09 16:36:08
         compiled from "view/templates/partial_form_login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:117685727655268e5838d883-63919548%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7ee83f8fa54c72fa72956d4813cd6ec162b6d1f7' => 
    array (
      0 => 'view/templates/partial_form_login.tpl',
      1 => 1428536380,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '117685727655268e5838d883-63919548',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_55268e58393e05_77893724',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55268e58393e05_77893724')) {function content_55268e58393e05_77893724($_smarty_tpl) {?><div class="section-your-review">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h3 class="page-header text-center text-uppercase">
                    <a name="my-review" href="#my-review" class="smooth-scroll">
                        <small><span class="glyphicon glyphicon-log-in"></span></small> Write a review
                    </a>
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <h4 class="text-center">
                    You need to log in or register for this service
                </h4>
                <?php echo $_smarty_tpl->getSubTemplate ("partial_errors.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

                <p class="text-center">
                    <button type="button" class="btn btn-primary" href="#service-modal" data-toggle="modal" data-target="#service-modal">Login / Register / Forgot</button>
                </p>
            </div>
        </div>
    </div>
</div><?php }} ?>
