<?php /* Smarty version Smarty-3.1.21, created on 2015-04-10 01:42:29
         compiled from "view/templates/partial_admin_menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:102075914155270b4638dc64-04379815%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4d5a5217e7a10b5d28955b27dd81270fbc4ce154' => 
    array (
      0 => 'view/templates/partial_admin_menu.tpl',
      1 => 1428622948,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '102075914155270b4638dc64-04379815',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_55270b463b9c01_29738354',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55270b463b9c01_29738354')) {function content_55270b463b9c01_29738354($_smarty_tpl) {?>                <li><a href="#change-psw-modal" data-toggle="modal" data-target="#change-psw-modal">Change Password</a></li>
                <li><a href="/user/logout">Logout</a></li><?php }} ?>
