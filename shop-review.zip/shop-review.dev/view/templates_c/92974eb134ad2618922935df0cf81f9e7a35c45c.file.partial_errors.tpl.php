<?php /* Smarty version Smarty-3.1.21, created on 2015-04-09 01:39:41
         compiled from "view/templates/partial_errors.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6089199535525bc3d3cb9c0-41046153%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92974eb134ad2618922935df0cf81f9e7a35c45c' => 
    array (
      0 => 'view/templates/partial_errors.tpl',
      1 => 1428536349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6089199535525bc3d3cb9c0-41046153',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'form_errors' => 0,
    'error' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5525bc3d3e9438_14902783',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5525bc3d3e9438_14902783')) {function content_5525bc3d3e9438_14902783($_smarty_tpl) {?><?php if (!empty($_smarty_tpl->tpl_vars['form_errors']->value)) {?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <ul class="">
    <?php  $_smarty_tpl->tpl_vars['error'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['error']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['form_errors']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['error']->key => $_smarty_tpl->tpl_vars['error']->value) {
$_smarty_tpl->tpl_vars['error']->_loop = true;
?>
        <li><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</li>
    <?php } ?>
    </ul>
</div>
<?php }?><?php }} ?>
