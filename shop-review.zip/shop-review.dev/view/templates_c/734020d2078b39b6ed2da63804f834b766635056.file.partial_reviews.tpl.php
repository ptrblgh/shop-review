<?php /* Smarty version Smarty-3.1.21, created on 2015-04-14 14:15:55
         compiled from "view/templates/partial_reviews.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18482112375528e83c148825-17642630%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '734020d2078b39b6ed2da63804f834b766635056' => 
    array (
      0 => 'view/templates/partial_reviews.tpl',
      1 => 1429013381,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18482112375528e83c148825-17642630',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21',
  'unifunc' => 'content_5528e83c16ec54_31650770',
  'variables' => 
  array (
    'reviews' => 0,
    'review' => 0,
    'review_body' => 0,
    'review_lead' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5528e83c16ec54_31650770')) {function content_5528e83c16ec54_31650770($_smarty_tpl) {?><?php if (!empty($_smarty_tpl->tpl_vars['reviews']->value)) {?>
    <?php  $_smarty_tpl->tpl_vars['review'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['review']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['reviews']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['review']->key => $_smarty_tpl->tpl_vars['review']->value) {
$_smarty_tpl->tpl_vars['review']->_loop = true;
?>
        <?php $_smarty_tpl->tpl_vars["review_body"] = new Smarty_variable($_smarty_tpl->tpl_vars['review']->value->review_body, null, 0);?>
            <div class="media">
                <div class="hidden-xs media-left media-top">
                    <span class="glyphicon glyphicon-user"></span>
                </div>
                <div class="media-body">
                    <h4 class="media-heading"><a name="<?php echo $_smarty_tpl->tpl_vars['review']->value->username;?>
" href="#<?php echo $_smarty_tpl->tpl_vars['review']->value->username;?>
" class="smooth-scroll"><?php echo $_smarty_tpl->tpl_vars['review']->value->username;?>
</a> <small class="media-date">@ <?php echo $_smarty_tpl->tpl_vars['review']->value->review_add_date;?>
</small></h4>
                    <input class="rating" value="<?php echo $_smarty_tpl->tpl_vars['review']->value->review_rating;?>
" data-min="0" data-max="5" data-step="1" data-readonly="true" data-size="xs">
                    <p>
<?php if (strlen($_smarty_tpl->tpl_vars['review_body']->value)>$_smarty_tpl->tpl_vars['review_lead']->value) {?>
    <?php echo nl2br(substr($_smarty_tpl->tpl_vars['review_body']->value,0,strpos($_smarty_tpl->tpl_vars['review_body']->value,' ',$_smarty_tpl->tpl_vars['review_lead']->value)));?>
<a class="collapse-btn" href="#"> <small class="glyphicon glyphicon-plus"></small> more </a> <span class="collapse-body"><?php echo nl2br(substr($_smarty_tpl->tpl_vars['review_body']->value,strpos($_smarty_tpl->tpl_vars['review_body']->value,' ',$_smarty_tpl->tpl_vars['review_lead']->value)+1));?>
</span>
<?php } else { ?>
    <?php echo nl2br($_smarty_tpl->tpl_vars['review_body']->value);?>

<?php }?>
                    </p>
                </div>
            </div>
    <?php } ?>
<?php } else { ?>
    <p class="text-center">No other reviews so far. You can be the first one!</p>
<?php }?>            
<?php }} ?>
